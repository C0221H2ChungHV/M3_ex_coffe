<?php

namespace App\Http\Controllers;

use App\Models\CategoryModel;
use App\Models\ProductModel;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    private $product;
    private $category;
    public function __construct(ProductModel $product, CategoryModel $category)
    {
        $this->product = $product;
        $this->category = $category;
    }

    public function index()
    {
        $products = $this->product->paginate(4);
        return view('product.index', compact('products'));
    }

    public function create()
    {
        $categories = $this->category->all();
        return view('product.add', compact('categories'));
    }

    public function store(Request $request)
    {
        $data_upload = [
            'name'=>$request->name,
            'price'=>$request->price,
            'category_id'=>$request->category_id
        ];
        if ($request->hasFile('image')) {
            $fileExtension = $request->image->getClientOriginalExtension();
            $fileName = hexdec(uniqid('', false));

            $data_upload['image'] = "$fileName.$fileExtension";

            $request->file('image')->storeAs('/public/images', $data_upload['image']);
        }
        $this->product->create($data_upload);
        return redirect()->route('products.index');

    }

    public function delete($id)
    {
        $this->product->find($id)->delete();
        return redirect()->route('products.index');
    }

    public function edit($id)
    {
        $categories = $this->category->all();
        $product = $this->product->find($id);
        return view('product.edit', compact('product','categories' ));
    }

    public function update(Request $request,$id)
    {
        $data_update = [
            'name'=>$request->name,
            'price'=>$request->price,
            'category_id'=>$request->category_id
        ];
        if ($request->hasFile('image')) {
            $fileExtension = $request->image->getClientOriginalExtension();
            $fileName = hexdec(uniqid('', false));

            $data_upload['image'] = "$fileName.$fileExtension";

            $request->file('image')->storeAs('/public/images', $data_upload['image']);
        }
        $this->product->find($id)->update($data_update);
        return redirect()->route('products.index');
    }

    public function show($id)
    {
        $product = $this->product->find($id);
        return view('product.show', compact('product'));
    }
    public function search(Request $request)
    {
        $price1 = $request->price1;
        $price2 = $request->price2;
        $products = ProductModel::where('price','>', $price1)->where('price','<', $price2)->paginate(4);
        return view('product.search', compact('products'));
    }
}
