@extends('layout')
@section('content')



    <section>
        <div class="container">
            <div class="row">
                <div>
                    <a href="{{route('products.index')}}" class="btn btn-primary">Trang chủ</a>
                    <a href="{{route('products.create')}}" class="btn btn-primary">Thêm sản phẩm</a>
                </div>
                <div class="col-md-12">
                    <div class="features_items"><!--features_items-->
                        <h2 class="title text-center">Sản Phẩm</h2>
                            <div class="col-md-3">
                                <div class="product-image-wrapper">
                                    <div class="single-products">
                                        <div class="productinfo text-center">
                                            <img style="height: 200px; width: 250px" src="{{asset('storage/images/'.$product->image)}}" alt="image.png"/>
                                            <h2>{{number_format($product->price)}} VNĐ</h2>
                                            <p style="color: black; font-size: larger">{{$product->name}}</p>
                                            <a href="{{route('products.show',['id'=>$product->id])}}" class="btn btn-info">Chi tiết</a>
                                            |
                                            <a href="{{route('products.edit',['id'=>$product->id])}}"
                                               class="btn btn-success">Sửa</a>
                                            |
                                            <a href="{{route('products.delete',['id'=>$product->id])}}"
                                               class="btn btn-danger">Xóa</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div><!--features_items-->
                </div>
            </div>
        </div>
    </section>

@endsection

