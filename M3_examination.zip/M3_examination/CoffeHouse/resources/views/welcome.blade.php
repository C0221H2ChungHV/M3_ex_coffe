@extends('layout')
@section('content')
    <a class="btn btn-primary" href="{{route('products.index')}}">Sản Phẩm</a>
    <a class="btn btn-primary" href="{{route('categories.index')}}">Danh Mục Sản Phẩm</a>
@endsection
