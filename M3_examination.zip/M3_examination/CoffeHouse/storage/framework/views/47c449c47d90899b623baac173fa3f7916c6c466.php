<?php $__env->startSection('content'); ?>
    <div class="content-wrapper">
        <div class="content">

            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <form method="post" id="form-add" action="<?php echo e(route('categories.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Tên danh mục</label>
                                <input type="text" class="form-control" name="category_name" placeholder="Nhập tên danh mục" >
                            </div>
                            <div class="form-group">
                                <label>Mô tả danh mục</label>
                                <input type="text" class="form-control" name="description" placeholder="Nhập mô tả danh mục" >
                            </div>
                            <button type="submit"  class="btn btn-success">Submit</button>

                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M3/CoffeHouse/resources/views/category/add.blade.php ENDPATH**/ ?>