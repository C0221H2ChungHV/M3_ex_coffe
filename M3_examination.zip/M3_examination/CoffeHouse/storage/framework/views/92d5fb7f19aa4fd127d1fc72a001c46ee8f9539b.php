<?php $__env->startSection('content'); ?>
    <form method="post" action="<?php echo e(route('products.update',['id'=>$product->id])); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleInputEmail1">Tên sản phẩm</label>
            <input type="text" name="name" value="<?php echo e($product->name); ?>" class="form-control" id="exampleInputEmail1"
                   aria-describedby="emailHelp" placeholder="Nhập tên sản phẩm">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Giá sản phẩm</label>
            <input type="number" name="price" value="<?php echo e($product->price); ?>" class="form-control"
                   id="exampleInputPassword1" placeholder="Nhập giá sản phẩm">
        </div>
        <div class="form-group">
            <label for="exampleInputPassword1">Chọn ảnh</label>
            <img src="<?php echo e(asset('storage/images/'.$product->image)); ?>" alt="image.png"/>
            <input type="file" class="form-control" id="exampleCheck1" name="image">
        </div>
        <div class="form-group">
            <label>Chọn danh mục </label>
            <select class="form-control select2_init" name="category_id">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($category->id==$product->category_id): ?>
                        <option value="<?php echo e($category->id); ?>" selected><?php echo e($category->category_name); ?></option>
                    <?php else: ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e($category->category_name); ?></option>
                    <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Submit</button>
    </form>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M3/CoffeHouse/resources/views/product/edit.blade.php ENDPATH**/ ?>