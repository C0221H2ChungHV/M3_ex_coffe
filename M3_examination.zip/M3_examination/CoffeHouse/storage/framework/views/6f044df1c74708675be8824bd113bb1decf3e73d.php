<?php $__env->startSection('content'); ?>



    <section>
        <div class="container">
            <div class="row">
                <div>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Trang chủ</a>
                    <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Thêm sản phẩm</a>
                </div>
                <div class="col-md-12">
                    <div class="features_items"><!--features_items-->
                        <h2 class="title text-center">Sản Phẩm</h2>
                            <div class="col-md-3">
                                <div class="product-image-wrapper">
                                    <div class="single-products">
                                        <div class="productinfo text-center">
                                            <img style="height: 200px; width: 250px" src="<?php echo e(asset('storage/images/'.$product->image)); ?>" alt="image.png"/>
                                            <h2><?php echo e(number_format($product->price)); ?> VNĐ</h2>
                                            <p style="color: black; font-size: larger"><?php echo e($product->name); ?></p>
                                            <a href="<?php echo e(route('products.show',['id'=>$product->id])); ?>" class="btn btn-info">Chi tiết</a>
                                            |
                                            <a href="<?php echo e(route('products.edit',['id'=>$product->id])); ?>"
                                               class="btn btn-success">Sửa</a>
                                            |
                                            <a href="<?php echo e(route('products.delete',['id'=>$product->id])); ?>"
                                               class="btn btn-danger">Xóa</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                    </div><!--features_items-->
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M3/CoffeHouse/resources/views/product/show.blade.php ENDPATH**/ ?>