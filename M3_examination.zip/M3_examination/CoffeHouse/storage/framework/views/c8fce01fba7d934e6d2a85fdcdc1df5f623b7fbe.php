<?php $__env->startSection('content'); ?>



    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="col-md-6 float-left">
                        <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Trang chủ</a>
                        <a href="<?php echo e(route('products.create')); ?>" class="btn btn-primary">Thêm sản phẩm</a>
                    </div>
                    <div class="col-md-6 float-right">
                        <form>
                            Từ <input type="number" name="price1" min="0"> Đến <input type="number" name="price2" min="0">
                            <button class="btn btn-primary">Tìm kiếm theo khoảng giá</button>
                        </form>

                    </div>

                </div>
                <div class="col-md-12">
                    <div class="features_items"><!--features_items-->
                        <h2 class="title text-center">Sản Phẩm</h2>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <div class="product-image-wrapper">
                                    <div class="single-products">
                                        <div class="productinfo text-center">
                                            <img style="height: 200px; width: 250px" src="<?php echo e(asset('storage/images/'.$product->image)); ?>" alt="image.png"/>
                                            <h2><?php echo e(number_format($product->price)); ?> VNĐ</h2>
                                            <p style="color: black; font-size: larger"><?php echo e($product->name); ?></p>
                                            <a href="<?php echo e(route('products.show',['id'=>$product->id])); ?>" class="btn btn-info">Chi tiết</a>
                                            |
                                            <a href="<?php echo e(route('products.edit',['id'=>$product->id])); ?>"
                                               class="btn btn-success">Sửa</a>
                                            |
                                            <a href="<?php echo e(route('products.delete',['id'=>$product->id])); ?>"
                                               class="btn btn-danger">Xóa</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div><!--features_items-->
                </div>
                <div class="col-md-12"><?php echo e($products->appends(request()->query())); ?> </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M3/CoffeHouse/resources/views/product/search.blade.php ENDPATH**/ ?>