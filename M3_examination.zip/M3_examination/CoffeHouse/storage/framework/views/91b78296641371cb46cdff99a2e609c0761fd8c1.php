<?php $__env->startSection('content'); ?>
    <a class="btn btn-primary" href="<?php echo e(route('products.index')); ?>">Sản Phẩm</a>
    <a class="btn btn-primary" href="<?php echo e(route('categories.index')); ?>">Danh Mục Sản Phẩm</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/M3/CoffeHouse/resources/views/welcome.blade.php ENDPATH**/ ?>